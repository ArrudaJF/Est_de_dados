typedef struct ponto Ponto;

Ponto* makePonto(float x, float y);
float getPonto(Ponto* point, char c);
