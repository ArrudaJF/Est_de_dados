Arquivo zip gerado em: 24/09/2022 16:12:11 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 02 - Catálogo de jogos